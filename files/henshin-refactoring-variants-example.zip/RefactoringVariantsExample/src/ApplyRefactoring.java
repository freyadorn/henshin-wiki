import java.util.HashMap;
import java.util.Map;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.emf.henshin.interpreter.EGraph;
import org.eclipse.emf.henshin.interpreter.Engine;
import org.eclipse.emf.henshin.interpreter.impl.EGraphImpl;
import org.eclipse.emf.henshin.interpreter.impl.EngineImpl;
import org.eclipse.emf.henshin.interpreter.impl.RuleApplicationImpl;
import org.eclipse.emf.henshin.model.HenshinPackage;
import org.eclipse.emf.henshin.model.Module;
import org.eclipse.emf.henshin.model.Rule;
import org.eclipse.emf.henshin.model.resource.HenshinResourceSet;
import org.eclipse.emf.henshin.variability.VarRuleApplicationImpl;

public class ApplyRefactoring {

	@SuppressWarnings("serial")
	public static void main(String[] args) {
		HenshinResourceSet resourceSet = new HenshinResourceSet("src");
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("xmi", new XMIResourceFactoryImpl());
		Resource model = resourceSet.getResource("classmodel1.xmi");
		HenshinPackage.eINSTANCE.eClass();
		Engine engine = new EngineImpl();
		EGraph egraph = new EGraphImpl(model);
		Module module = resourceSet.getModule("refactorings-variability.henshin");
		Rule rule = (Rule) module.getUnit("moveMethod");

		System.out.println("### Applying rule variant without wrapper and annotation ###");
		Map<String, Boolean> configurationWithoutWrapperAndAnno = new HashMap<String, Boolean>() {
			{
				put("wrapper", true);
				put("deprecated", true);
			}
		};
		RuleApplicationImpl vbRuleApp = new VarRuleApplicationImpl(engine, egraph, rule, configurationWithoutWrapperAndAnno, null);
		vbRuleApp.setParameterValue("src", "Zookeeper");
		vbRuleApp.setParameterValue("trg", "Zoo");
		vbRuleApp.setParameterValue("m", "openZoo");
		executeApplication(egraph, vbRuleApp);

		System.out.println("### Applying rule variant without wrapper and annotation ###");
		Map<String, Boolean> configurationWithWrapperAndAnno = new HashMap<String, Boolean>() {
			{
				put("wrapper", false);
				put("deprecated", false);
			}
		};
		vbRuleApp = new VarRuleApplicationImpl(engine, egraph, rule, configurationWithWrapperAndAnno, null);
		vbRuleApp.setParameterValue("src", "Zookeeper");
		vbRuleApp.setParameterValue("trg", "Zoo");
		vbRuleApp.setParameterValue("m", "openZoo");
		executeApplication(egraph, vbRuleApp);

	}

	private static void executeApplication(EGraph egraph, RuleApplicationImpl vbRuleApp) {
		printContainmentTree(egraph.getRoots().get(0));
		boolean result = vbRuleApp.execute(null);
		System.out.println(result ? "Application successful." : "Application failed.");
		printContainmentTree(egraph.getRoots().get(0));
		result = vbRuleApp.undo(null);
		System.out.println(result ? "Undo successful." : "Undo failed.");
	}

	public static void printContainmentTree(EObject root) {
		printContainmentTreeRecursive(root, 0);
	}

	private static void printContainmentTreeRecursive(EObject object, int depth) {
		for (int i = 0; i < depth * 2; i++) {
			System.out.print("  ");
		}
		EStructuralFeature nameFeature = object.eClass().getEStructuralFeature("name");
		if (nameFeature == null)
			System.out.println("[" + object.eClass().getName() + "]");
		else
			System.out.println("[" + object.eClass().getName() + "] name");

		for (EObject o : object.eContents())
			printContainmentTreeRecursive(o, depth + 1);
	}
}
