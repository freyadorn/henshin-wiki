/**
 */
package boxing;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Item</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link boxing.Item#getIsStoredBy <em>Is Stored By</em>}</li>
 * </ul>
 *
 * @see boxing.BoxingPackage#getItem()
 * @model
 * @generated
 */
public interface Item extends EObject {
	/**
	 * Returns the value of the '<em><b>Is Stored By</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link boxing.Box#getStores <em>Stores</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Stored By</em>' reference.
	 * @see #setIsStoredBy(Box)
	 * @see boxing.BoxingPackage#getItem_IsStoredBy()
	 * @see boxing.Box#getStores
	 * @model opposite="stores"
	 * @generated
	 */
	Box getIsStoredBy();

	/**
	 * Sets the value of the '{@link boxing.Item#getIsStoredBy <em>Is Stored By</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Stored By</em>' reference.
	 * @see #getIsStoredBy()
	 * @generated
	 */
	void setIsStoredBy(Box value);

} // Item
